package com.example.assignment1;

public class Readings {
    Integer HeartRate;
    Integer Headache;
    Integer cough;
    Integer Diarrhea;
    Integer smellandtaste;
    Integer Sorethroat;
    Integer Tireness;
    Integer Shortnessofbreath;
    Integer Fever;
    Integer Muscleache;
    Integer Nausea;
    Integer Respiratoryrate;
    String Username;

    public Readings(Integer HeartRate, Integer Respiratoryrate, Integer Headache, Integer Diarrhea, Integer Sorethroat, Integer Fever, Integer Muscleache, Integer smellandtaste, Integer cough, Integer Shortnessofbreath, Integer Tireness, String USER_NAME, Integer NAUSEA) {
        this.HeartRate = HeartRate;
        this.Respiratoryrate = Respiratoryrate;
        this.Headache = Headache;
        this.Diarrhea = Diarrhea;
        this.Sorethroat = Sorethroat;
        this.Fever = Fever;
        this.Muscleache = Muscleache;
        this.smellandtaste = smellandtaste;
        this.cough = cough;
        this.Shortnessofbreath = Shortnessofbreath;
        this.Tireness = Tireness;
        this.Username = USER_NAME;
        this.Nausea = NAUSEA;
    }

    public Integer getHeartRate() { return HeartRate; }

    public void set(Integer HeartRate) {
        this.HeartRate = HeartRate;
    }

    public Integer getRespiratoryrate() {
        return Respiratoryrate;
    }

    public void setRespiratoryrate(Integer Respiratoryrate) {
        this.Respiratoryrate = Respiratoryrate;
    }

    public Integer getHeadache() {
        return Headache;
    }

    public void setHeadache(Integer Headache) {
        this.Headache = Headache;
    }

    public Integer getDiarrhea() {
        return Diarrhea;
    }

    public void setDiarrhea(Integer Diarrhea) {
        this.Diarrhea = Diarrhea;
    }

    public Integer getSorethroat() {
        return Sorethroat;
    }

    public void setSorethroat(Integer Sorethroat) {
        this.Sorethroat = Sorethroat;
    }

    public Integer getFever() {
        return Fever;
    }

    public void setFever(Integer Fever) {
        this.Fever = Fever;
    }

    public Integer getMuscleache() {
        return Muscleache;
    }

    public void setMMuscleache(Integer Muscleache) {
        this.Muscleache = Muscleache;
    }

    public Integer getsmellandtaste() {
        return smellandtaste;
    }

    public void setsmellandtaste(Integer smellandtaste) {
        this.smellandtaste = smellandtaste;
    }

    public Integer getcough() {
        return cough;
    }

    public void setcough(Integer cough) {
        this.cough = cough;
    }

    public Integer getShortnessofbreath() {
        return Shortnessofbreath;
    }

    public void setShortnessofbreath(Integer Shortnessofbreath) {
        this.Shortnessofbreath = Shortnessofbreath;
    }

    public Integer getTireness() { return Tireness; }

    public void setTireness(Integer Tireness) {
        this.Tireness = Tireness;
    }

    public String getUSER_NAME() {
        return USER_NAME;
    }

    public void setUSER_NAME(String USER_NAME) {
        this.USER_NAME = USER_NAME;
    }

    public Integer getNAUSEA() {
        return NAUSEA;
    }

    public void setNAUSEA(Integer NAUSEA) {
        this.NAUSEA = NAUSEA;
    }
}
