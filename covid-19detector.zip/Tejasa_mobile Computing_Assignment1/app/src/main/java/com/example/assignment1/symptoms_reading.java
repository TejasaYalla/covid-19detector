package com.example.assignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

public class symptoms_reading extends AppCompatActivity {
    Spinner symptoms_dropdown_spinner;
    RatingBar ratingBar;
    Button upload_symptoms_btn;
    String selectedSymptom = "";
    ProgressBar progressBar;
    TextView textView;
    float selectedRating =0;
    String user_name="";
    int headache =0;
    int diarrhea =0;
    int sore_throat =0;
    int fever =0;
    int muscle_ache =0;
    int loss_smell =0;
    int cough =0;
    int shortness_breath =0;
    int feeling_tired=0;
    int nausea =0;
    boolean symptomChanged =false;
    boolean ratingChanged = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle extras = getIntent().getExtras();
        if(extras == null){
            user_name = "";
        }else{
            user_name = extras.getString("name");
        }
        setContentView(R.layout.activity_symptoms_reading);
        symptoms_dropdown_spinner = findViewById(R.id.symtpoms_dropdown);
        ratingBar = findViewById(R.id.symptom_level_rating);
        progressBar = findViewById(R.id.symptoms_progress);
        textView = findViewById(R.id.symptoms_text);
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.symptoms_array));
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        symptoms_dropdown_spinner.setAdapter(spinnerAdapter);
        uploadSymptoms();
        onChangeSymptom();
        ratingChange();
    }
    public void ratingChange(){
        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                updateData(rating);
            }
        });
    }
    public void updateData(float rating){
        switch(selectedSymptom){
            case "Headache": headache = (int) rating;
            break;
            case "Diarrhea": diarrhea = (int) rating;
            break;
            case "Sore Throat": sore_throat = (int) rating;
            break;
            case "Fever": fever = (int) rating;
            break;
            case "Muscle Ache": muscle_ache = (int) rating;
            break;
            case "Loss of Smell or Taste": loss_smell = (int) rating;
            break;
            case "Cough": cough = (int) rating;
            break;
            case "Shortness of breath": shortness_breath = (int) rating;
            break;
            case "feeling tired": feeling_tired = (int) rating;
            break;
            case "Nausea": nausea = (int) rating;
            break;
            default: return;
        }
    }
    public void onChangeSymptom(){
        symptoms_dropdown_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedSymptom = parent.getSelectedItem().toString();
                int currentRating = setRating(selectedSymptom);
                ratingBar.setRating(currentRating);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
    public int setRating(String symptom){
        switch(symptom){
            case "Headache": return headache;
            case "Diarrhea": return diarrhea;
            case "Sore Throat": return sore_throat;
            case "Fever": return fever;
            case "Muscle Ache": return muscle_ache;
            case "Loss of Smell or Taste": return loss_smell;
            case "Cough": return cough;
            case "Shortness of breath": return shortness_breath;
            case "feeling tired": return feeling_tired;
            case "Nausea": return nausea;
            default:  return 0;
        }
    }
    public void uploadSymptoms() {
        upload_symptoms_btn = findViewById(R.id.upload_symptoms);
        upload_symptoms_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);
                textView.setText("Uploading data....Please wait");
                selectedRating = ratingBar.getRating();
                DatabaseHelper databaseAction = new DatabaseHelper(getApplicationContext());
                Toast.makeText(getApplicationContext(), user_name, Toast.LENGTH_SHORT).show();
                Readings readings = new Readings(0, 0, headache, diarrhea, sore_throat, fever, muscle_ache, loss_smell, cough, shortness_breath, feeling_tired, user_name, nausea);
                if (databaseAction.update(readings) == true) {
                    Toast.makeText(getApplicationContext(), "Data updated successfully", Toast.LENGTH_LONG).show();
                    textView.setVisibility(View.INVISIBLE);
                    progressBar.setVisibility(View.INVISIBLE);
                }
            }
        });
    }
}