package com.example.assignment1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String HEART_RATE = "HEART_RATE";
    public static final String RESPIRATORY_RATE = "RESPIRATORY_RATE";
    public static final String FEELING_TIRED = "FEELING_TIRED";
    public static final String SHORTNESS_OF_BREATH = "SHORTNESS_OF_BREATH";
    public static final String COUGH = "COUGH";
    public static final String LOSS_SMELL_TASTE = "LOSS_SMELL_TASTE";
    public static final String MUSCLE_ACHE = "MUSCLE_ACHE";
    public static final String FEVER = "FEVER";
    public static final String SORE_THROAT = "SORE_THROAT";
    public static final String DIARRHEA = "DIARRHEA";
    public static final String HEADACHE = "HEADACHE";
    public static final String ID = "ID";
    public static final String METRICS_TABLE = "METRICS_TABLE";
    public static final String USER_NAME = "USER_NAME";
    public static final String NAUSEA = "NAUSEA";

    public DatabaseHelper(@Nullable Context context) {
        super(context, "metrics.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createMetricsTableStatement = "CREATE TABLE " + METRICS_TABLE + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, " + USER_NAME + " STRING, "  + NAUSEA + " INTEGER," +HEART_RATE + " INTEGER, " + RESPIRATORY_RATE + " INTEGER, " + HEADACHE + " INTEGER, " + DIARRHEA + " INTEGER, " + SORE_THROAT + " INTEGER, " + FEVER + " INTEGER, " + MUSCLE_ACHE + " INTEGER, " + LOSS_SMELL_TASTE + " INTEGER, " + COUGH + " INTEGER, " + SHORTNESS_OF_BREATH + " INTEGER, " + FEELING_TIRED + " INTEGER)";
        db.execSQL(createMetricsTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


    }
    public boolean onInsert(Readings readings){
        SQLiteDatabase database =this.getWritableDatabase();
        ContentValues readingValues = new ContentValues();
        readingValues.put(HEART_RATE,readings.HEART_RATE);
        readingValues.put(RESPIRATORY_RATE,readings.RESPIRATORY_RATE);
        readingValues.put(HEADACHE,readings.HEADACHE);
        readingValues.put(DIARRHEA,readings.DIARRHEA);
        readingValues.put(SORE_THROAT,readings.SORE_THROAT);
        readingValues.put(FEVER,readings.FEVER);
        readingValues.put(MUSCLE_ACHE,readings.MUSCLE_ACHE);
        readingValues.put(LOSS_SMELL_TASTE,readings.LOSS_SMELL_TASTE);
        readingValues.put(COUGH,readings.COUGH);
        readingValues.put(SHORTNESS_OF_BREATH,readings.SHORTNESS_BREATH);
        readingValues.put(FEELING_TIRED,readings.FEELING_TIRED);
        readingValues.put(USER_NAME,readings.USER_NAME);
        readingValues.put(NAUSEA,readings.NAUSEA);
        long insert = database.insert(METRICS_TABLE, null, readingValues);
        if(insert== -1){
            return false;
        }
        else{
            return true;
        }
    }
    public boolean update(Readings readings){
            SQLiteDatabase database = this.getWritableDatabase();
        String selectQuery = "SELECT  * FROM  METRICS_TABLE";
        Cursor cursor = database.rawQuery(selectQuery, null);
        int Id = cursor.getCount();
        Log.d("Saitama", "Latest ID"+Id);
        ContentValues readingValues = new ContentValues();
            readingValues.put(HEADACHE,readings.HEADACHE);
            readingValues.put(DIARRHEA,readings.DIARRHEA);
            readingValues.put(SORE_THROAT,readings.SORE_THROAT);
            readingValues.put(FEVER,readings.FEVER);
            readingValues.put(MUSCLE_ACHE,readings.MUSCLE_ACHE);
            readingValues.put(LOSS_SMELL_TASTE,readings.LOSS_SMELL_TASTE);
            readingValues.put(COUGH,readings.COUGH);
            readingValues.put(SHORTNESS_OF_BREATH,readings.SHORTNESS_BREATH);
            readingValues.put(FEELING_TIRED,readings.FEELING_TIRED);
            readingValues.put(USER_NAME,readings.USER_NAME);
            readingValues.put(NAUSEA,readings.NAUSEA);
//             database.execSQL("UPDATE METRICS_TABLE SET HEADACHE='" + readings.HEADACHE + "',DIARRHEA='" + readings.DIARRHEA + "',SORE_THROAT='"  + readings.SORE_THROAT +"' WHERE ID='" + Id + "'");
//             return true;
        long result = database.update(METRICS_TABLE, readingValues, "ID = ?", new String[]{String.valueOf(Id)});
        if(result == -1){
            return false;
        }else{
            return true;
        }
    }
}
