package com.example.assignment1;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.util.ArrayList;

public class dashboard extends AppCompatActivity {
    CardView symptomsCard, respiratory_card,heartRate_card;
    ProgressBar progressBar;
    String user_name ="";
    Button upload_signs;
    int differenceThreashhold = 12;
    int indexFrame = 0;
    int totalframes = 0;
    int outputHeartRate =0;
    int finalHeartRate=0;
    int finalrespiratoryRate =0;
    ArrayList<Float> bloodcolors = new ArrayList<Float>();
    private static int VIDEO_REQUEST =101;
    private static int REQUEST_PERMISSION =1;
    private static int READ_PERMISSION = 102;
    private static int WRITE_PERMISSION = 103;
    private Uri videoUri;
    Intent videoIntent;
    VideoView videoView;
    TextView respiratoryTextView, heartRateTextView, respiratoryValueText;
    int respiratoryRate =0;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == VIDEO_REQUEST && resultCode == RESULT_OK){
            Uri VideoUri = data.getData();
            String sampleUri = VideoUri.toString();
            videoUri = Uri.parse(sampleUri);
            respiratoryTextView.setText("Measuring heart rate, please wait");
            progressBar.setVisibility(View.VISIBLE);
            redirectToVideo();
            HeartRateCalculatorTask myHRCalc = new HeartRateCalculatorTask();
            myHRCalc.execute(videoUri);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_dashboard);
        respiratoryTextView = (TextView) findViewById(R.id.respiratoryTextView);
        heartRateTextView = findViewById(R.id.heartRateTextView);
        respiratoryValueText = findViewById(R.id.respiratoryValue);
        upload_signs = findViewById(R.id.upload_signs);
        videoView = findViewById(R.id.videoView);
        progressBar = findViewById(R.id.progressBar);
        super.onCreate(savedInstanceState);
        Bundle extras = getIntent().getExtras();
        if(extras == null){
            user_name ="";
        }else{
            user_name = extras.getString("name");
        }
        symptomsCard = findViewById(R.id.symptomscard);
        respiratory_card = findViewById(R.id.respiratoryCard);
        heartRate_card = findViewById(R.id.heartRateCard);
        buttonClick();
        measuringRespiratoryRate();
        measuringHeartRate();
        uploadSigns();
    }
    private BroadcastReceiver bReceiver = new BroadcastReceiver(){

        @Override
        public void onReceive(Context context, Intent intent) {
            String str = (String) intent.getExtras().get("success").toString();
            respiratoryValueText.setVisibility(View.VISIBLE);
            respiratoryValueText.setText("Respiratoryrate is " +str);
            progressBar.setVisibility(View.INVISIBLE);
            respiratoryRate = Integer.parseInt(str);
            respiratoryTextView.setVisibility(View.INVISIBLE);
        }
    };

    protected void onResume(){
        super.onResume();
        LocalBroadcastManager.getInstance(this).registerReceiver(bReceiver, new IntentFilter("message"));
    }

    protected void onPause (){
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(bReceiver);
    }
    public void buttonClick(){
        symptomsCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent symptomsIntent = new Intent(getApplicationContext(),symptoms_reading.class);
                symptomsIntent.putExtra("name",user_name);
                startActivity(symptomsIntent);
            }
        });
    }
    public void measuringRespiratoryRate(){
        respiratory_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Respiration clicked",Toast.LENGTH_LONG).show();
                Intent respiratoryIntentService = new Intent(getApplicationContext(),RespiratoryService.class);
                startService(respiratoryIntentService);
                progressBar.setVisibility(View.VISIBLE);
                respiratoryTextView.setVisibility(View.VISIBLE);
                respiratoryTextView.setText("Respiratory rate measuring,please wait");
            }
        });
    }
    public void measuringHeartRate(){
        heartRate_card.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                videoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                videoIntent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 45);
                videoIntent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                videoIntent.setFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                if(ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED){
                    if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                            if (videoIntent.resolveActivity(getPackageManager()) != null) {
                                startActivityForResult(videoIntent, VIDEO_REQUEST);
                            }
                        } else {
                            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQUEST_PERMISSION);
                            if (videoIntent.resolveActivity(getPackageManager()) != null) {
                                startActivityForResult(videoIntent, VIDEO_REQUEST);
                            }
                        }
                    }else{
                        requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, READ_PERMISSION);
                        if (videoIntent.resolveActivity(getPackageManager()) != null) {
                            startActivityForResult(videoIntent, VIDEO_REQUEST);
                        }
                    }
                }else{
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, WRITE_PERMISSION);
                    if (videoIntent.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(videoIntent, VIDEO_REQUEST);
                    }
                }

            }
        });
    }
    public void redirectToVideo(){
        videoView.setVisibility(View.VISIBLE);
        videoView.setVideoURI(videoUri);
        videoView.setMediaController(new MediaController(this));
        videoView.requestFocus();
        videoView.start();
    }
    class HeartRateCalculatorTask extends AsyncTask<Uri, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @RequiresApi(api = Build.VERSION_CODES.R)
        @Override
        protected Void doInBackground(Uri... uris) {
            MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
            try {
                metaRetriever.setDataSource(getApplicationContext(),videoUri);
            }
            catch (Exception e){
                e.printStackTrace();
            }
            MediaPlayer forTime = MediaPlayer.create(getBaseContext(),videoUri);
            int videoDuration = forTime.getDuration();
            int processFramesPerSec = 12;
            int processtime = 100000;
            totalframes = (int) Math.floor(videoDuration/1000) * processFramesPerSec;
            outputHeartRate = 1;
            indexFrame = 1;
            while(indexFrame < totalframes){
                float currentColor = 0f;
                Bitmap currentFrameBitmap = metaRetriever.getFrameAtTime(processtime,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                processtime = processtime + 100000;
                Log.d("Saitama", "Processing frame number"+processtime);
                //Get an area of image
                int i = 450;
                while(i <= 550){
                    int j = 900;
                    while(j < 1200){
                        currentColor = currentColor + Color.red(currentFrameBitmap.getPixel(i,j));
                        j++;
                    }
                    i++;
                }

                float previousColor = 1f;
                boolean isArrayListEmpty = (bloodcolors.size()!=0);
                if(isArrayListEmpty!=false){
                    int currentSize = bloodcolors.size();
                    previousColor = bloodcolors.get(currentSize - 1); //-1 because index starts at 0
                }

                boolean isCountable = Math.abs(previousColor - currentColor) > differenceThreashhold;
                if(isCountable == true){
                    outputHeartRate++;
                }

                bloodcolors.add(currentColor);

                Log.d("Saitama", "Processing frame number"+processtime);
                indexFrame++;

            }

            metaRetriever.release();
            Log.d("Saitama", "Sending heart rate"+ outputHeartRate);

            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            heartRateTextView.setText("HeartRate Value : " + String.valueOf(outputHeartRate));
            heartRateTextView.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.INVISIBLE);
            respiratoryTextView.setVisibility(View.INVISIBLE);
//            uploadData();
        }
    }
    public void uploadData(){
        DatabaseHelper databaseAction = new DatabaseHelper(getApplicationContext());
        Readings reading = new Readings(outputHeartRate,0,0,0,0,0,0,0,0,0,0,user_name,0);
        if(databaseAction.onInsert(reading)== true){
            Toast.makeText(getApplicationContext(), "Data updated successfully",Toast.LENGTH_LONG).show();
        }
    }
    public void uploadSigns(){
        upload_signs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseHelper databaseAction = new DatabaseHelper(getApplicationContext());
                Readings reading = new Readings(outputHeartRate,respiratoryRate,0,0,0,0,0,0,0,0,0,user_name,0);
                if(databaseAction.onInsert(reading)== true){
                    Toast.makeText(getApplicationContext(), "Data updated successfully",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

}